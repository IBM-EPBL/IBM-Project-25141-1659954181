# ASSIGNMENT 04
    Working with Docker and Kubernetes and deploy as Nodeport.

[NODEPORT LINK FLASK APP](http://169.51.203.223:31274/)
